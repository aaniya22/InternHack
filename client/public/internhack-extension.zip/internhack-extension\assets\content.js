const ee=[{kind:"coverLetter",patterns:[/cover\s*letter/i,/why\s+do\s+you\s+want\s+to\s+work/i,/note\s+to\s+(the\s+)?hiring\s+manager/i]},{kind:"firstName",patterns:[/first\s*name/i,/given\s*name/i]},{kind:"lastName",patterns:[/last\s*name/i,/family\s*name/i,/surname/i]},{kind:"fullName",patterns:[/full\s*name/i,/^name$/i,/legal\s*name/i]},{kind:"email",patterns:[/e-?mail/i,/email\s*address/i]},{kind:"phone",patterns:[/phone/i,/mobile/i,/contact\s*number/i]},{kind:"location",patterns:[/location/i,/city/i,/current\s*address/i]},{kind:"linkedinUrl",patterns:[/linkedin/i]},{kind:"githubUrl",patterns:[/github/i]},{kind:"portfolioUrl",patterns:[/portfolio/i,/website/i,/personal\s*site/i]},{kind:"leetcodeUrl",patterns:[/leetcode/i]},{kind:"school",patterns:[/school/i,/university/i,/college/i,/institution/i]},{kind:"graduationYear",patterns:[/graduation\s*year/i,/grad\s*year/i,/expected\s*graduation/i]},{kind:"skills",patterns:[/skills/i,/technologies/i,/tech\s*stack/i]},{kind:"resumeUrl",patterns:[/resume/i,/cv/i]},{kind:"bio",patterns:[/summary/i,/about/i]}];function S(e){return e?.textContent?.replace(/\s+/g," ").trim()||""}function z(e){const t=e.getAttribute("aria-label")||e.getAttribute("placeholder")||"",o=e.getAttribute("name")||e.getAttribute("id")||"",r=e.getAttribute("id"),n=r?document.querySelector(`label[for="${CSS.escape(r)}"]`):null,l=e.closest("label"),m=e.closest("div,fieldset,section");return[t,S(n),S(l),o,S(m)].filter(Boolean).join(" ").replace(/\s+/g," ").trim()}function te(e,t){const o=t.getAttribute("type")||"",r=t.getAttribute("autocomplete")||"",n=`${e} ${o} ${r}`;if(o==="email"||r==="email")return{kind:"email",confidence:.95};if(o==="tel"||r.includes("tel"))return{kind:"phone",confidence:.9};if(o==="file"&&/resume|cv/i.test(e))return{kind:"resumeUrl",confidence:.85};for(const l of ee)if(l.patterns.some(m=>m.test(n)))return{kind:l.kind,confidence:.78};return t.tagName==="TEXTAREA"?{kind:"customQuestion",confidence:.42}:{kind:"unknown",confidence:0}}function oe(e){const t=e.getAttribute("type")?.toLowerCase();if(["password","hidden","submit","button","reset","checkbox","radio"].includes(t||"")||e.disabled||(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)&&e.readOnly)return!1;const o=z(e);return!/password|credit card|card number|captcha|security code|ssn|social security/i.test(o)}function ne(e=document){return Array.from(e.querySelectorAll("input, textarea, select")).filter(oe).map(o=>{const r=z(o),n=te(r,o);return{element:o,label:r,...n}}).filter(o=>o.kind!=="unknown")}function re(){const e=document.title.replace(/\s+/g," ").trim(),[t,o]=e.split(/\s[-|]\s/);return{role:t||"Open role",company:o||location.hostname.replace(/^www\./,"")}}function j(e){for(const t of e){const o=document.querySelector(t)?.textContent?.replace(/\s+/g," ").trim();if(o)return o}return""}class b{siteType="GENERIC";detect(){return document.querySelectorAll("form, input, textarea, select").length>0}extractJobContext(){const t=re(),o=j(["h1","[data-testid*=title]",".job-title"])||t.role,r=j(["[data-testid*=company]",".company",".company-name"])||t.company,n=j(["[data-testid*=description]",".job-description","main"]);return{company:r,role:o,jobUrl:location.href,applicationUrl:location.href,jobDescription:n||null,siteType:this.siteType,host:location.hostname}}findFields(){return ne(document)}}class ie extends b{siteType="ASHBY";detect(){return/ashbyhq\.com/i.test(location.hostname)||!!document.querySelector("[data-ashby], form[action*='ashby']")}}class ae extends b{siteType="GREENHOUSE";detect(){return/greenhouse\.io/i.test(location.hostname)||!!document.querySelector("#grnhse_app, form[action*='greenhouse']")}}class se extends b{siteType="INDEED";detect(){return/indeed\.com/i.test(location.hostname)&&!!document.querySelector("form, [data-testid*='apply']")}}class le extends b{siteType="LEVER";detect(){return/lever\.co/i.test(location.hostname)||!!document.querySelector(".posting, form[action*='lever']")}}class ce extends b{siteType="LINKEDIN";detect(){if(!/linkedin\.com/i.test(location.hostname))return!1;const t=/\/jobs\//i.test(location.pathname),o=!!document.querySelector(".jobs-easy-apply-modal, .jobs-apply-button, .job-details-jobs-unified-top-card, .jobs-search__job-details, .jobs-details, [data-job-id]");return t||o}}function C(e){for(const t of e){const o=document.querySelector(t)?.textContent?.replace(/\s+/g," ").trim();if(o)return o}return""}class de extends b{siteType="WELLFOUND";detect(){return/wellfound\.com|angel\.co/i.test(location.hostname)?/\/jobs\/|\/company\/[^/]+\/jobs|\/l\/|\/apply/i.test(location.pathname)||!!document.querySelector("[data-test='JobDetail'], [data-test='JobApplicationForm'], form[action*='apply']"):!1}extractJobContext(){const t=super.extractJobContext(),o=C(["[data-test='JobDetail'] h1","h1","h2"])||t.role,r=C(["[data-test='StartupHeader'] h1","[data-test='JobDetail'] a[href*='/company/']","a[href*='/company/']"])||t.company,n=C(["[data-test='JobDescription']","#job-description","main section"])||t.jobDescription||"";return{...t,role:o,company:r,jobDescription:n||null,siteType:this.siteType}}}class pe extends b{siteType="WORKDAY";detect(){return/workdayjobs\.com/i.test(location.hostname)||!!document.querySelector("[data-automation-id], form[action*='workday']")}}function T(){return[new ce,new pe,new ae,new le,new ie,new se,new de].find(t=>t.detect())??new b}function ue(e){return e!=="customQuestion"&&e!=="unknown"}function fe(e,t){return ue(t.kind)&&(e[t.kind]||e.customFields[t.label])||""}function $(e,t){const o=Object.getPrototypeOf(e);Object.getOwnPropertyDescriptor(o,"value")?.set?.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function B(e){const t=e.style.boxShadow;e.style.boxShadow="0 0 0 2px #a3e635",window.setTimeout(()=>{e.style.boxShadow=t},1400)}function me(e,t){const o=e.filter(n=>n.kind==="coverLetter"||n.kind==="customQuestion"&&/cover\s*letter/i.test(n.label));let r=0;for(const n of o)n.element instanceof HTMLSelectElement||n.element.type!=="file"&&($(n.element,t),B(n.element),n.element.scrollIntoView({behavior:"smooth",block:"center"}),r+=1);return{targetCount:o.length,filledCount:r}}function ge(e,t){let o=0;const r=[];for(const n of t){const l=fe(e,n);if(!(!l||n.confidence<.55)&&!n.element.value.trim())try{if(n.element instanceof HTMLSelectElement){const m=Array.from(n.element.options).find(p=>p.text.toLowerCase().includes(l.toLowerCase())||p.value.toLowerCase().includes(l.toLowerCase()));if(!m)continue;$(n.element,m.value)}else if(n.element.type==="file"){r.push(n);continue}else $(n.element,l);B(n.element),o+=1}catch{r.push(n)}}return{fieldCount:t.length,filledCount:o,failedCount:r.length,failed:r}}const he=[["JavaScript","javascript","js","ecmascript","es6"],["TypeScript","typescript","ts"],["Python","python"],["Java","java"],["C++","c++","cpp"],["C#","c#","csharp",".net","dotnet"],["Go","golang","go lang"],["Rust","rust"],["Ruby","ruby"],["PHP","php"],["Swift","swift"],["Kotlin","kotlin"],["Scala","scala"],["R","r language"],["SQL","sql"],["Bash","bash","shell scripting"],["HTML","html","html5"],["CSS","css","css3"],["Solidity","solidity"],["React","react","react.js","reactjs"],["Next.js","next.js","nextjs"],["Angular","angular","angularjs"],["Vue","vue","vue.js","vuejs"],["Svelte","svelte","sveltekit"],["Redux","redux"],["Tailwind CSS","tailwind","tailwindcss"],["Bootstrap","bootstrap"],["SASS","sass","scss"],["Webpack","webpack"],["Vite","vite"],["React Native","react native"],["Flutter","flutter"],["Android","android"],["iOS","ios"],["Node.js","node.js","nodejs","node js"],["Express","express","express.js","expressjs"],["NestJS","nestjs","nest.js"],["Django","django"],["Flask","flask"],["FastAPI","fastapi"],["Spring Boot","spring boot","springboot","spring"],["Rails","rails","ruby on rails"],["Laravel","laravel"],["GraphQL","graphql"],["REST API","rest api","restful","rest apis"],["gRPC","grpc"],["WebSockets","websocket","websockets"],["Microservices","microservice","microservices"],["PostgreSQL","postgresql","postgres"],["MySQL","mysql"],["MongoDB","mongodb","mongo"],["Redis","redis"],["Elasticsearch","elasticsearch","elastic search"],["DynamoDB","dynamodb"],["Cassandra","cassandra"],["Snowflake","snowflake"],["Kafka","kafka"],["RabbitMQ","rabbitmq"],["Spark","apache spark","pyspark"],["Hadoop","hadoop"],["Airflow","airflow"],["ETL","etl"],["Data Modeling","data modeling","data modelling"],["Prisma","prisma"],["SQLAlchemy","sqlalchemy"],["Data Structures","data structures"],["Algorithms","algorithms"],["AWS","aws","amazon web services"],["Azure","azure"],["GCP","gcp","google cloud"],["Docker","docker"],["Kubernetes","kubernetes","k8s"],["Terraform","terraform"],["Jenkins","jenkins"],["CI/CD","ci/cd","cicd","continuous integration","continuous deployment"],["Linux","linux","unix"],["Nginx","nginx"],["Serverless","serverless","lambda"],["Vercel","vercel"],["Git","git","github","gitlab","version control"],["Monitoring","monitoring","observability","datadog","prometheus","grafana"],["Machine Learning","machine learning","ml"],["Deep Learning","deep learning"],["NLP","nlp","natural language processing"],["Computer Vision","computer vision","opencv"],["TensorFlow","tensorflow"],["PyTorch","pytorch"],["scikit-learn","scikit-learn","sklearn"],["Pandas","pandas"],["NumPy","numpy"],["LLM","llm","large language model","generative ai","genai"],["RAG","rag","retrieval augmented generation"],["Data Analysis","data analysis","data analytics"],["Tableau","tableau"],["Power BI","power bi","powerbi"],["Excel","excel"],["Testing","unit testing","unit tests","integration testing","test automation"],["Jest","jest"],["Cypress","cypress"],["Playwright","playwright"],["Selenium","selenium"],["Pytest","pytest"],["Agile","agile","scrum","kanban"],["System Design","system design","distributed systems"],["Object Oriented Programming","object oriented","oop"],["Code Review","code review","code reviews"],["Debugging","debugging","troubleshooting"],["Performance Optimization","performance optimization","performance tuning","scalability"],["Security","security","authentication","authorization","oauth","jwt"],["Accessibility","accessibility","a11y","wcag"],["Responsive Design","responsive design","responsive"],["Figma","figma"],["UI/UX","ui/ux","user experience","ux design"],["Jira","jira"],["Documentation","documentation","technical writing"],["Communication","communication","communicate effectively"],["Collaboration","collaboration","cross-functional","cross functional","teamwork"],["Problem Solving","problem solving","problem-solving"],["Ownership","ownership","self-starter","self starter"],["Mentoring","mentoring","mentorship"],["Stakeholder Management","stakeholder","stakeholders"],["Product Sense","product sense","product thinking"]];function ye(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function be(e){return new RegExp(`(^|[^a-z0-9+#.])${ye(e)}([^a-z0-9+#]|$)`,"i")}const F=he.map(([e,...t])=>({label:e,patterns:(t.length?t:[e.toLowerCase()]).map(be)}));function q(e){return` ${e.replace(/\s+/g," ").toLowerCase()} `}function G(e,t){return t.some(o=>o.test(e))}function ve(e,t=24){const o=q(e),r=[];for(const n of F)if(G(o,n.patterns)&&r.push(n.label),r.length>=t)break;return r}function xe(e){const{user:t,applicationProfile:o}=e;return[t.name,t.bio||"",t.college||"",t.skills.join(" "),JSON.stringify(t.projects??""),JSON.stringify(o?.education??""),JSON.stringify(o?.experience??""),JSON.stringify(o?.customFields??"")].filter(Boolean).join(" ")}function ke(e,t){const o=ve(e),r=q(xe(t)),n=[],l=[];for(const m of o){const p=F.find(k=>k.label===m);p&&G(r,p.patterns)?n.push(m):l.push(m)}return{score:o.length?Math.round(n.length/o.length*100):0,total:o.length,matched:n,missing:l}}function we(e){return typeof e=="string"?e:""}function Ee(e){const t=e.trim().split(/\s+/).filter(Boolean);return{firstName:t[0]||"",lastName:t.slice(1).join(" ")}}function D(e){const t=e.applicationProfile?.legalName||e.user.name,o=e.applicationProfile?.preferredName||t,r=Ee(o),n=Object.fromEntries(Object.entries(e.applicationProfile?.customFields??{}).map(([l,m])=>[l,we(m)]).filter(([,l])=>l));return{firstName:r.firstName,lastName:r.lastName,fullName:o,email:e.user.email,phone:e.user.contactNo||"",location:e.user.location||"",linkedinUrl:e.user.linkedinUrl||"",githubUrl:e.user.githubUrl||"",portfolioUrl:e.user.portfolioUrl||"",leetcodeUrl:e.user.leetcodeUrl||"",school:e.user.college||"",graduationYear:e.user.graduationYear?String(e.user.graduationYear):"",skills:e.user.skills.join(", "),resumeUrl:e.user.resumes[0]||"",bio:e.user.bio||"",coverLetter:"",customFields:n}}const N="internhack-autofill-panel",R="internhack-autofill-launcher",J=chrome.runtime.getURL("logo.png");function y(e){return chrome.runtime.sendMessage(e)}function u(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function v(e,t){if(!e||typeof e!="object")return"";const o=e;for(const r of t){const n=o[r];if(typeof n=="string"&&n.trim())return n.trim();if(typeof n=="number")return String(n)}return""}function w(e){const t=!!e&&typeof e=="object"&&e.current===!0,o=v(e,["startDate","start","from"]),r=v(e,["endDate","end","to"])||(t?"Present":"");return[o,r].filter(Boolean).join(" - ")}const Le=`
  :host { all: initial; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .drawer {
    position: absolute; inset: 0;
    display: flex; flex-direction: column;
    background: #ffffff; color: #1c1917;
    font-family: Inter, "Segoe UI", Arial, sans-serif; font-size: 13px; line-height: 1.5;
    border-left: 1px solid #d6d3d1;
    box-shadow: -12px 0 40px rgba(0,0,0,.16);
    z-index: 2147483647;
  }
  header { display: flex; align-items: center; gap: 10px; padding: 14px 16px; border-bottom: 1px solid #e7e5e4; }
  header img { width: 26px; height: 26px; border-radius: 6px; object-fit: contain; flex: none; }
  .brand { flex: 1; min-width: 0; }
  .kicker { font-size: 10px; text-transform: uppercase; letter-spacing: .14em; color: #78716c; }
  .brand strong { display: block; font-size: 14px; font-weight: 700; }
  .job { padding: 12px 16px; border-bottom: 1px solid #e7e5e4; background: #fafaf9; }
  .job .role { font-size: 15px; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .job .company { font-size: 12px; color: #78716c; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  nav { display: flex; border-bottom: 1px solid #e7e5e4; }
  nav button {
    flex: 1; border: 0; background: transparent; cursor: pointer;
    font: inherit; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .1em;
    color: #78716c; padding: 11px 4px; border-bottom: 2px solid transparent;
  }
  nav button:hover { color: #1c1917; }
  nav button[aria-selected="true"] { color: #1c1917; border-bottom-color: #a3e635; }
  .body { flex: 1; overflow-y: auto; padding: 16px; display: grid; gap: 16px; align-content: start; }
  .actions { display: grid; gap: 8px; padding: 12px 16px; border-top: 1px solid #e7e5e4; background: #fafaf9; }
  footer { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 16px; border-top: 1px solid #e7e5e4; }
  button.primary { border: 0; border-radius: 6px; background: #a3e635; color: #1c1917; font: inherit; font-weight: 700; padding: 10px; cursor: pointer; }
  button.primary:hover { background: #84cc16; }
  button.secondary { border: 1px solid #d6d3d1; border-radius: 6px; background: #fff; color: #1c1917; font: inherit; font-weight: 700; padding: 9px 12px; cursor: pointer; }
  button.secondary:hover { border-color: #a8a29e; }
  button.quiet { border: 0; background: transparent; color: #57534e; font: inherit; font-size: 12px; cursor: pointer; padding: 4px 0; text-decoration: underline; }
  button:disabled { opacity: .55; cursor: default; }
  .score { display: flex; align-items: center; gap: 14px; border: 1px solid #e7e5e4; border-radius: 8px; padding: 14px; }
  .score .value { flex: none; width: 62px; height: 62px; border-radius: 8px; background: #ecfccb; color: #3f6212; display: flex; align-items: center; justify-content: center; font-size: 19px; font-weight: 800; }
  .score .value.low { background: #fafaf9; color: #78716c; }
  .score h3 { font-size: 14px; font-weight: 700; }
  .score p { font-size: 12px; color: #57534e; margin-top: 2px; }
  .section h4 { font-size: 10px; text-transform: uppercase; letter-spacing: .14em; color: #78716c; margin-bottom: 8px; }
  .tags { display: flex; flex-wrap: wrap; gap: 6px; }
  .tag { border-radius: 4px; padding: 3px 7px; font-size: 11px; font-weight: 600; border: 1px solid transparent; }
  .tag.hit { background: #ecfccb; color: #3f6212; border-color: #d9f99d; }
  .tag.miss { background: #fafaf9; color: #57534e; border-color: #e7e5e4; }
  .rows { display: grid; gap: 7px; }
  .row { display: grid; grid-template-columns: 108px 1fr; gap: 10px; align-items: start; font-size: 12px; }
  .row dt { color: #78716c; }
  .row dd { color: #1c1917; overflow-wrap: anywhere; }
  .entry { border: 1px solid #e7e5e4; border-radius: 6px; padding: 9px 10px; }
  .entry strong { font-size: 12px; }
  .entry span { display: block; font-size: 11px; color: #78716c; }
  .muted { font-size: 12px; color: #78716c; }
  textarea, input {
    width: 100%; font: inherit; font-size: 12px; color: #1c1917; background: #fff;
    border: 1px solid #d6d3d1; border-radius: 6px; padding: 9px;
  }
  textarea { min-height: 260px; resize: vertical; line-height: 1.6; }
  input:focus, textarea:focus { outline: none; border-color: #a3e635; }
  .status { font-size: 12px; color: #78716c; min-height: 18px; }
  .status.error { color: #b91c1c; }
  a { color: #3f6212; }
`;function E(){document.getElementById(N)?.remove(),document.getElementById(R)?.remove()}function Se(e){E();const t=document.createElement("div");t.id=R,t.style.cssText="position:fixed !important;right:16px !important;bottom:16px !important;z-index:2147483647 !important";const o=t.attachShadow({mode:"open"});o.innerHTML=`
    <style>
      button {
        all: initial; cursor: pointer; display: flex; align-items: center; justify-content: center;
        width: 44px; height: 44px; border-radius: 8px; background: #fff;
        border: 1px solid #d6d3d1; box-shadow: 0 8px 24px rgba(0,0,0,.18);
      }
      button:hover { border-color: #a3e635; }
      img { width: 24px; height: 24px; object-fit: contain; }
    </style>
    <button type="button" title="Open InternHack Autofill" aria-label="Open InternHack Autofill">
      <img src="${J}" alt="" />
    </button>
  `,o.querySelector("button")?.addEventListener("click",()=>_(e)),document.documentElement.appendChild(t)}function _(e){E();const t={context:e,tab:"match",profile:null,profileError:"",match:null,usage:null,coverLetter:"",hasKey:!1,model:""},o=document.createElement("div");o.id=N,o.style.cssText=["position:fixed !important","top:0 !important","right:0 !important","bottom:0 !important","left:auto !important","width:420px !important","max-width:100vw !important","height:100vh !important","margin:0 !important","padding:0 !important","display:block !important","visibility:visible !important","opacity:1 !important","transform:none !important","z-index:2147483647 !important"].join(";");const r=o.attachShadow({mode:"open"});r.innerHTML=`
    <style>${Le}</style>
    <aside class="drawer" role="complementary" aria-label="InternHack Autofill">
      <header>
        <img src="${J}" alt="" />
        <div class="brand">
          <div class="kicker">InternHack / ${u(e.siteType)}</div>
          <strong>Autofill</strong>
        </div>
        <button class="secondary" data-action="close" title="Close">Close</button>
      </header>
      <div class="job">
        <div class="role" data-role></div>
        <div class="company" data-company></div>
      </div>
      <nav role="tablist">
        <button role="tab" data-tab="match">Match</button>
        <button role="tab" data-tab="cover">Cover letter</button>
        <button role="tab" data-tab="profile">Profile</button>
      </nav>
      <div class="body" data-body></div>
      <div class="actions">
        <button class="primary" data-action="fill">Autofill page</button>
        <button class="secondary" data-action="track">Track application</button>
        <div class="status" data-status></div>
      </div>
      <footer>
        <span class="kicker">Time saved</span>
        <span data-usage class="muted">...</span>
      </footer>
    </aside>
  `;const n=i=>r.querySelector(i),l=n("[data-body]"),m=n("[data-status]");n("[data-role]").textContent=e.role,n("[data-company]").textContent=[e.company,e.location].filter(Boolean).join(" / ");const p=(i,a=!1)=>{m.textContent=i,m.className=a?"status error":"status"},k=()=>{const i=t.usage;n("[data-usage]").textContent=i?`${i.timeSavedLabel} · ${i.stats.fieldsFilled} fields · ${i.stats.coverLetters} letters`:"Nothing yet"};function Y(){if(t.profileError){l.innerHTML=`<p class="muted">${u(t.profileError)}</p>`;return}if(!t.match){l.innerHTML='<p class="muted">Reading the job description...</p>';return}const{score:i,total:a,matched:c,missing:s}=t.match;if(!a){l.innerHTML=`
        <div class="section">
          <h4>Resume match</h4>
          <p class="muted">No recognisable skill keywords in this posting, so there is nothing to compare yet. Autofill still works.</p>
        </div>`;return}l.innerHTML=`
      <div class="score">
        <div class="value${i<40?" low":""}">${i}%</div>
        <div>
          <h3>Resume match</h3>
          <p><strong>${c.length} of ${a} keywords</strong> from this job are in your InternHack profile.</p>
        </div>
      </div>
      ${c.length?`
      <div class="section">
        <h4>In your profile (${c.length})</h4>
        <div class="tags">${c.map(g=>`<span class="tag hit">${u(g)}</span>`).join("")}</div>
      </div>`:""}
      ${s.length?`
      <div class="section">
        <h4>Missing (${s.length})</h4>
        <div class="tags">${s.map(g=>`<span class="tag miss">${u(g)}</span>`).join("")}</div>
        <p class="muted" style="margin-top:8px">Add the ones you genuinely have to your InternHack profile, then reload this page.</p>
      </div>`:""}
    `}function Q(){if(!t.hasKey){l.innerHTML=`
        <div class="section">
          <h4>OpenRouter API key</h4>
          <p class="muted">Cover letters are generated with your own OpenRouter key. It is stored in this browser only.</p>
          <div style="display:grid;gap:8px;margin-top:10px">
            <input type="password" data-key placeholder="sk-or-v1-..." autocomplete="off" />
            <input type="text" data-model placeholder="Model" value="${u(t.model)}" />
            <button class="primary" data-action="save-key">Save key</button>
          </div>
          <p class="muted" style="margin-top:10px">Get a key at <a href="https://openrouter.ai/keys" target="_blank" rel="noreferrer">openrouter.ai/keys</a>.</p>
        </div>`,n("[data-action='save-key']").addEventListener("click",async()=>{const a=n("[data-key]").value.trim(),c=n("[data-model]").value.trim();if(!a){p("Enter your OpenRouter API key.",!0);return}const s=await y({type:"SET_SETTINGS",payload:{openRouterApiKey:a,openRouterModel:c||t.model}});t.hasKey=!!s.openRouterApiKey,t.model=s.openRouterModel,p("OpenRouter key saved."),x()});return}l.innerHTML=`
      <div class="section">
        <h4>AI cover letter</h4>
        <p class="muted">Written from this job description and your InternHack profile, using ${u(t.model)}.</p>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button class="primary" data-action="generate" style="flex:1">${t.coverLetter?"Regenerate":"Generate cover letter"}</button>
        </div>
      </div>
      <div class="section">
        <textarea data-letter placeholder="Your cover letter appears here. Edit it before filling.">${u(t.coverLetter)}</textarea>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="secondary" data-action="fill-letter" style="flex:1">Fill into form</button>
          <button class="secondary" data-action="copy-letter">Copy</button>
        </div>
      </div>
      <button class="quiet" data-action="change-key">Change OpenRouter key</button>
    `;const i=n("[data-letter]");i.addEventListener("input",()=>{t.coverLetter=i.value}),n("[data-action='generate']").addEventListener("click",async a=>{const c=a.currentTarget;c.disabled=!0,p("Generating cover letter...");try{const s=await y({type:"GENERATE_COVER_LETTER",payload:{context:t.context}});if(s.error||!s.coverLetter)throw new Error(s.error||"Generation failed.");t.coverLetter=s.coverLetter,i.value=s.coverLetter,p("Cover letter ready. Edit it, then fill it in."),L(),x()}catch(s){p(s.message||"Could not generate the cover letter.",!0)}finally{c.disabled=!1}}),n("[data-action='fill-letter']").addEventListener("click",()=>{const a=i.value.trim();if(!a){p("Generate or paste a cover letter first.",!0);return}const c=me(T().findFields(),a);p(c.filledCount?`Cover letter filled into ${c.filledCount} field${c.filledCount>1?"s":""}.`:"No cover letter field found on this page. Copy it instead.",c.filledCount===0)}),n("[data-action='copy-letter']").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(i.value),p("Cover letter copied.")}catch{p("Could not copy. Select the text and copy manually.",!0)}}),n("[data-action='change-key']").addEventListener("click",()=>{t.hasKey=!1,x()})}function W(){if(t.profileError){l.innerHTML=`<p class="muted">${u(t.profileError)}</p>`;return}if(!t.profile){l.innerHTML='<p class="muted">Loading your profile...</p>';return}const i=t.profile,a=D(i),c=i.applicationProfile,s=(d,f)=>f?`<div class="row"><dt>${u(d)}</dt><dd>${u(f)}</dd></div>`:"",g=(d,f)=>f?`<div class="row"><dt>${u(d)}</dt><dd><a href="${u(f)}" target="_blank" rel="noreferrer">${u(f)}</a></dd></div>`:"",P=Array.isArray(c?.education)?c.education:[],I=Array.isArray(c?.experience)?c.experience:[],X=Object.entries(c?.customFields??{}).filter(([d])=>/language/i.test(d)).map(([,d])=>String(d)).join(", "),Z=P.length?P.map(d=>{const f=v(d,["institution","school","college","university","name"]),h=[v(d,["degree","qualification"]),v(d,["field","fieldOfStudy","major"])].filter(Boolean).join(", ");return!f&&!h?"":`<div class="entry"><strong>${u(f||h)}</strong>
              ${h&&f?`<span>${u(h)}</span>`:""}
              ${w(d)?`<span>${u(w(d))}</span>`:""}</div>`}).filter(Boolean).join(""):"",O=I.length?I.map(d=>{const f=v(d,["company","employer","organisation","organization"]),h=v(d,["title","position","role","jobTitle"]);return!f&&!h?"":`<div class="entry"><strong>${u(h||f)}</strong>
              ${h&&f?`<span>${u(f)}</span>`:""}
              ${w(d)?`<span>${u(w(d))}</span>`:""}</div>`}).filter(Boolean).join(""):"",M=Object.entries(c?.customFields??{}).filter(([d])=>!/language/i.test(d));l.innerHTML=`
      <div class="section">
        <h4>Used to fill this form</h4>
        <div class="rows">
          ${s("Name",a.fullName)}
          ${s("Email",a.email)}
          ${s("Phone",[c?.phoneCountryCode||"",a.phone].filter(Boolean).join(" "))}
          ${s("Location",a.location)}
          ${s("Languages",X)}
        </div>
      </div>
      <div class="section">
        <h4>Links</h4>
        <div class="rows">
          ${g("LinkedIn",a.linkedinUrl)}
          ${g("GitHub",a.githubUrl)}
          ${g("Portfolio",a.portfolioUrl)}
          ${g("LeetCode",a.leetcodeUrl)}
          ${g("Resume",a.resumeUrl)}
        </div>
        ${i.user.resumes.length>1?`<p class="muted" style="margin-top:6px">${i.user.resumes.length} resumes on file, the first is used.</p>`:""}
      </div>
      <div class="section">
        <h4>Education</h4>
        ${Z||`<div class="rows">${s("College",a.school)}${s("Graduation",a.graduationYear)}</div>`}
      </div>
      ${O?`<div class="section"><h4>Experience</h4><div class="rows">${O}</div></div>`:""}
      <div class="section">
        <h4>Skills (${i.user.skills.length})</h4>
        ${i.user.skills.length?`<div class="tags">${i.user.skills.map(d=>`<span class="tag miss">${u(d)}</span>`).join("")}</div>`:'<p class="muted">No skills on your profile yet.</p>'}
      </div>
      ${a.bio?`<div class="section"><h4>Summary</h4><p class="muted">${u(a.bio)}</p></div>`:""}
      ${M.length?`<div class="section"><h4>Saved answers</h4><div class="rows">${M.map(([d,f])=>s(d,String(f))).join("")}</div></div>`:""}
      <p class="muted">Edit any of this on InternHack, then reload the page.</p>
    `}function x(){r.querySelectorAll("nav button").forEach(i=>{i.setAttribute("aria-selected",String(i.dataset.tab===t.tab))}),t.tab==="match"?Y():t.tab==="cover"?Q():W()}async function L(){t.usage=await y({type:"GET_USAGE"}),k()}r.querySelectorAll("nav button").forEach(i=>{i.addEventListener("click",()=>{t.tab=i.dataset.tab||"match",x()})}),n("[data-action='close']").addEventListener("click",()=>{Se(t.context)}),n("[data-action='fill']").addEventListener("click",async()=>{if(!t.profile){p(t.profileError||"Profile is still loading.",!!t.profileError);return}p("Filling the form...");const i=D(t.profile);i.coverLetter=t.coverLetter;const c=T().findFields(),s=ge(i,c);p(`Filled ${s.filledCount} of ${s.fieldCount} fields.`),t.usage=await y({type:"RECORD_AUTOFILL",payload:{filledCount:s.filledCount}}),k(),y({type:"LOG_EVENT",payload:{host:location.hostname,siteType:t.context.siteType,url:location.href,eventType:"AUTOFILLED",fieldCount:s.fieldCount,filledCount:s.filledCount,failedCount:s.failedCount}})}),n("[data-action='track']").addEventListener("click",async()=>{p("Tracking application...");try{const i=await y({type:"TRACK_APPLICATION",payload:{context:t.context,submitted:window.confirm("Did you submit this application?")}});if(i?.error)throw new Error(i.error);p("Application tracked in InternHack."),L()}catch(i){p(i.message||"Could not track application.",!0)}}),document.documentElement.appendChild(o),x(),(async()=>{const i=await y({type:"GET_SETTINGS"});t.hasKey=!!i.openRouterApiKey,t.model=i.openRouterModel,await L();try{const a=await y({type:"GET_PROFILE"});if(a.error||!a.user)throw new Error(a.error||"Not connected.");t.profile=a,t.match=ke(t.context.jobDescription||"",a)}catch(a){t.profileError=a.message||"Open InternHack while signed in to connect the extension."}x()})()}function je(e){return chrome.runtime.sendMessage(e)}function Ce(){const e=T(),t=document.getElementById(N);if(!e.detect()){E();return}if(t||document.getElementById(R))return;const o=e.extractJobContext();_(o),je({type:"LOG_EVENT",payload:{host:location.hostname,siteType:o.siteType,url:location.href,eventType:"DETECTED",metadata:{role:o.role,company:o.company}}})}let U=[];function A(){U.forEach(e=>clearTimeout(e)),U=[0,600,1500,3e3].map(e=>window.setTimeout(Ce,e))}let H=location.href;function K(){location.href!==H&&(H=location.href,E(),A())}const V=e=>{const t=history[e];history[e]=function(...o){const r=t.apply(this,o);return window.dispatchEvent(new Event("ih:locationchange")),r}};V("pushState");V("replaceState");window.addEventListener("popstate",K);window.addEventListener("ih:locationchange",K);document.readyState==="loading"?document.addEventListener("DOMContentLoaded",A,{once:!0}):A();
